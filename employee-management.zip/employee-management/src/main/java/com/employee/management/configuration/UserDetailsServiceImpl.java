package com.employee.management.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.employee.management.dao.EmployeeRepository;
import com.employee.management.entity.Employee;

public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		// fatching employee from database
		Employee emp = employeeRepository.findByEmail(username);

		if (emp == null) {

			throw new UsernameNotFoundException("Could Not Found Employee");
		}

		CustomUserDetails customUserDetails = new CustomUserDetails(emp);

		return customUserDetails;
	}

}
