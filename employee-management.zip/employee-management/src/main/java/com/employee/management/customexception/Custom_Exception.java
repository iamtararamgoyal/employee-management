package com.employee.management.customexception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Custom_Exception implements ErrorController {

	@RequestMapping(value = "/error")
	public String handleError(HttpServletRequest request) {
		return "redirect:/error-page";
	}

	@Override
	public String getErrorPath() {
		return "/error";
	}

}
