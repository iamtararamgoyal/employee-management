package com.employee.management.controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.employee.management.dao.EmployeeRepository;
import com.employee.management.entity.Employee;
import com.employee.management.helper.Messages;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private BCryptPasswordEncoder passwordEncode;

	// handler for accessing dashboard by as employee
	@GetMapping("/")
	public String dashboard(Model model, Principal principal) {

		try {

			Employee emp = employeeRepository.findByEmail(principal.getName());
			model.addAttribute("title", "Employee Dashboard");
			model.addAttribute("employee", emp);
			System.out.println(emp);
		} catch (Exception e) {
			return "/logout";
		}
		return "employee/home";
	}

	// handler for, request for accessing update myself
	@PostMapping("/edit")
	public String edit(Model model, Principal principal) {

		try {
			Employee emp = employeeRepository.findByEmail(principal.getName());
			if (emp == null) {
				return "employee/home";
			}
			model.addAttribute("title", "Employee Dashboard");
			model.addAttribute("employee", emp);
		} catch (Exception e) {
			return "employee/home";
		}
		return "employee/update";
	}

	// handler for updating employee myself
	@PostMapping("/update-employee")
	public String editEmployee(@ModelAttribute("employee") Employee emp, Model model, HttpSession session,
			Principal principal) {

		try {
			Employee employee = employeeRepository.getOne(emp.getId());

			if (employee != null) {
				if (!employee.getPassword().equals(emp.getPassword())) {
					emp.setPassword(passwordEncode.encode(emp.getPassword()));
				}

				// check for email already exist or not
				if (!employee.getEmail().equals(emp.getEmail())) {
					Employee findByEmail = employeeRepository.findByEmail(emp.getEmail());

					if (findByEmail != null) {
						session.setAttribute("email", "An account already exists for this email.");
						model.addAttribute("adminemployee", employee);
						return "employee/update";
					}

				}

				emp.setName(employee.getName());
				emp.setRole(employee.getRole());
				emp.setTeam(employee.getTeam());
				Employee updateEmp = employeeRepository.save(emp);
				model.addAttribute("title", "Update Employee");
				model.addAttribute("employee", updateEmp);
				session.setAttribute("message", new Messages("Employee Updated succesfully !!", "alert-success"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			session.setAttribute("message",
					new Messages("Something want to wrong.Please try again !!", "alert-danger"));
			return "redirect:/employee/";
		}
		return "employee/update";
	}

}
