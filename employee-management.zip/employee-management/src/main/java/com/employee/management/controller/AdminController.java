package com.employee.management.controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import com.employee.management.dao.EmployeeRepository;
import com.employee.management.entity.Employee;
import com.employee.management.helper.Messages;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	private BCryptPasswordEncoder passwordEncode;

	// handler for accesing dashboard by admin with pageable
	@GetMapping("/{page}")
	public String home(@PathVariable("page") Integer page, Model model, Principal principal) {

		try {
			Employee emp = employeeRepository.findByEmail(principal.getName());

			// Current Page -> pageable
			// Employee per page -> 3
			Pageable pageable = PageRequest.of(page, 3);

			Page<Employee> employees = employeeRepository.findAll(pageable);

			model.addAttribute("title", "Admin Dashboard");
			model.addAttribute("employee", emp);
			model.addAttribute("employees", employees);
			model.addAttribute("currentPage", page);
			model.addAttribute("totalPages", employees.getTotalPages());

			return "admin/home";
		} catch (Exception e) {
			return "/logout";
		}

	}

	// handler for, request for accessing an add new employee by admin
	@GetMapping("/add-employee")
	public String addEmployee(Model model, Principal principal) {

		try {
			Employee emp = employeeRepository.findByEmail(principal.getName());
			model.addAttribute("title", "Add Employee");
			model.addAttribute("employee", emp);
			model.addAttribute("adminemployee", new Employee());
		} catch (Exception e) {
			return "redirect:/admin/0";
		}
		return "admin/add-employee";
	}

	// handler for, delete an employee by admin
	@PostMapping("/delete")
	public String deleteEmployee(@ModelAttribute("employee") Employee emp, HttpSession session) {

		try {
			Employee employee = employeeRepository.findById(emp.getId()).get();
			if (employee == null)
				return "redirect:/admin/0";

			employeeRepository.delete(employee);
			session.setAttribute("message", new Messages("Employee deleted succesfully !!", "alert-success"));

		} catch (Exception e) {
			session.setAttribute("message",
					new Messages("Something want to wrong.Please try again !!", "alert-danger"));
		}

		return "redirect:/admin/0";
	}

	// handler for, request for accessing update an employee details by admin
	@PostMapping("/update")
	public String updateEmployee(@ModelAttribute("employee") Employee emp, Model model, HttpSession session) {

		try {
			Employee employee = employeeRepository.findById(emp.getId()).get();
			if (employee == null)
				return "redirect:/admin/0";
			model.addAttribute("title", "Update Employee");
			model.addAttribute("employee", employee);

		} catch (Exception e) {
			session.setAttribute("message",
					new Messages("Something want to wrong.Please try again !!", "alert-danger"));
			return "redirect:/admin/0";
		}
		return "admin/update";
	}

	// updating an employee by admin

	@PostMapping("/update-employee")
	public String editEmployee(@ModelAttribute("employee") Employee emp, Model model, HttpSession session) {

		try {

			Employee oldEmpData = employeeRepository.findById(emp.getId()).get();

			// checking for an unauthorized access
			if (oldEmpData == null) {
				return "redirect:/admin/0";
			}
			if (!emp.getPassword().equals(oldEmpData.getPassword())) {
				emp.setPassword(passwordEncode.encode(emp.getPassword()));
			}

			// befor updating an employee check email is already exist or not
			if (!oldEmpData.getEmail().equals(emp.getEmail())) {
				Employee findByEmail = employeeRepository.findByEmail(emp.getEmail());

				if (findByEmail != null) {
					session.setAttribute("email", "An account already exists for this email.");
					model.addAttribute("adminemployee", emp);
					return "admin/update";
				}

			}

			Employee updateEmp = employeeRepository.save(emp);

			model.addAttribute("title", "Update Employee");
			model.addAttribute("employee", updateEmp);

			session.setAttribute("message", new Messages("Employee Updated succesfully !!", "alert-success"));

		} catch (Exception e) {
			session.setAttribute("message",
					new Messages("Something want to wrong.Please try again !!", "alert-danger"));
			return "redirect:/admin/0";
		}

		return "admin/update";
	}

	// handler for register an employee by admin
	@PostMapping("/employee-register")
	public String addNewEmployee(@Valid @ModelAttribute("adminemployee") Employee employee, BindingResult bindingResult,
			Model model, HttpSession session) {

		try {

			if (bindingResult.hasErrors()) {
				System.out.println(bindingResult);
				model.addAttribute("employee", employee);
				model.addAttribute("adminemployee", employee);
				return "admin/add-employee";
			}

			Employee findByEmail = employeeRepository.findByEmail(employee.getEmail());

			// check for employee already exist or not
			if (findByEmail != null) {
				ObjectError er = new ObjectError("email", "An account already exists for this email.");
				bindingResult.addError(er);
				session.setAttribute("email", "An account already exists for this email.");
				model.addAttribute("adminemployee", employee);
				return "admin/add-employee";
			}

			employee.setRole("ROLE_USER");
			employee.setPassword(passwordEncode.encode(employee.getPassword()));

			this.employeeRepository.save(employee);

			model.addAttribute("employee", new Employee());
			session.setAttribute("email", "");
			session.setAttribute("message", new Messages("Successfully Register!!", "alert-success"));

		} catch (Exception e) {

			e.printStackTrace();
			model.addAttribute("employee", employee);
			session.setAttribute("message", new Messages("Something want wrong!!", "alert-danger"));
		}
		return "redirect:/admin/add-employee";
	}

}
