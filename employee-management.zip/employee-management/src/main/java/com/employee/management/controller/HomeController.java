package com.employee.management.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.employee.management.dao.EmployeeRepository;
import com.employee.management.entity.Employee;
import com.employee.management.helper.Messages;

@Controller
public class HomeController {

	@Autowired
	private BCryptPasswordEncoder passwordEncode;

	@Autowired
	private EmployeeRepository employeeRepository;

	// home handler
	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("title", "Home");
		return "home";
	}

	// about handler
	@GetMapping("/about")
	public String about(Model model) {

		model.addAttribute("title", "About");
		return "about";
	}

	// signup handler
	@GetMapping("/signup")
	public String signup(Model model) {

		model.addAttribute("title", "Signup");
		model.addAttribute("employee", new Employee());
		return "signup";
	}

	// signin handler
	@GetMapping("/signin")
	public String signin(Model model) {
		model.addAttribute("title", "Signin");

		return "signin";
	}

	/*
	 * @PostMapping("/login") public String login(Model model) {
	 * 
	 * model.addAttribute("title", "Signin");
	 * 
	 * return "redirect:/admin/0"; }
	 */

	@RequestMapping("/default")
	public String defaultAfterLogin(HttpServletRequest request) {
		if (request.isUserInRole("ROLE_ADMIN")) {
			return "redirect:/admin/0";
		}
		return "redirect:/employee/";
	}

	@PostMapping("/do_register")
	public String doRegister(@Valid @ModelAttribute("employee") Employee employee, BindingResult bindingResult,
			Model model, HttpSession session) {

		try {

			if (bindingResult.hasErrors()) {
				System.out.println(bindingResult);
				model.addAttribute("employee", employee);
				return "signup";
			}

			Employee findByEmail = employeeRepository.findByEmail(employee.getEmail());

			if (findByEmail != null) {
				ObjectError er = new ObjectError("email", "An account already exists for this email.");
				bindingResult.addError(er);
				session.setAttribute("email", "An account already exists for this email.");
				return "signup";
			}

			// based on role
			// model.addAttribute("title", "");

			// employee.setRole("ROLE_USER");
			employee.setPassword(passwordEncode.encode(employee.getPassword()));
			Employee save = this.employeeRepository.save(employee);
			System.out.println(save);
			model.addAttribute("employee", new Employee());
			session.setAttribute("email", "");
			session.setAttribute("message", new Messages("Successfully Register!!", "alert-success"));

		} catch (Exception e) {

			e.printStackTrace();
			model.addAttribute("employee", employee);
			session.setAttribute("message", new Messages("Something want wrong!!" + e.getMessage(), "alert-danger"));
		}
		return "redirect:/signup";

	}

	// handler for error/exception
	@RequestMapping("/error-page")
	public String error() {
		return "page-not-found";
	}

}
