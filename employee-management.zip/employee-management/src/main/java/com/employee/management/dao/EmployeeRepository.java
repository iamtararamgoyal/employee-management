package com.employee.management.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.management.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	public Employee findByEmail(String email);

	// Pagination
	// Current Page -> pageable
	// Employee per page -> 5
	public Page<Employee> findAll(Pageable pageable);

	

}
